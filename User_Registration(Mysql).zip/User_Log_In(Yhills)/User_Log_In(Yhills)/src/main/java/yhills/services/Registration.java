package yhills.services;

import java.io.Serializable;
import java.util.Iterator;
import java.util.List;

import javax.persistence.TypedQuery;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import yhills.classes.UserRegistration;
import yhills.connection.HiberConfig;

public class Registration {
	SessionFactory sf=HiberConfig.conn();
//	UserRegistration ures=null;
	
	public String AddUser(UserRegistration ures) {
		String res=null;
		
		Session sc=sf.openSession();
		Transaction ts=sc.beginTransaction();
		Serializable sr=sc.save(ures);
		ts.commit();
		if(sr!=null) {
			res="success";
		}
		sc.close();
		return res;
	}
	public boolean Search(String email) {
		boolean res=false;
		List<UserRegistration> list=null;
		Session sc=sf.openSession();
		TypedQuery qry=sc.createQuery("from UserRegistration where email=:em");
		qry.setParameter("em", email);
		list=qry.getResultList();
		Iterator it=list.iterator();
		sc.close();
		if(it.hasNext()) {
			res=true;
		}
		return res;
	}
	
	public List<UserRegistration> Fetch(String email) {
//		boolean res=false;
		List<UserRegistration> list=null;
		Session sc=sf.openSession();
		TypedQuery qry=sc.createQuery("from UserRegistration where email=:em");
		qry.setParameter("em", email);
		list=qry.getResultList();
		sc.close();
		return list;
	}
	
	public String ChangePass(String email,String pass) {
		String result=null;
		Session sc=sf.openSession();
		Transaction ts=sc.beginTransaction();
		
		TypedQuery qry=sc.createQuery("update UserRegistration set password=:pass where email=:em");
		qry.setParameter("pass", pass);
		qry.setParameter("em", email);
		
		int res=qry.executeUpdate();
		ts.commit();
		if(res>=1) {
			result="success";
		}
		sc.close();
		return result;
	}
}
